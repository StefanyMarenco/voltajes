package Login;

import java.util.Scanner;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc=new Scanner(System.in);
    String us="admin";
    int pass=123, cont=1;
    while(us!="admin" || pass!=123 || cont<=3) {
    	System.out.println("Ingrese un usuario");
    	us=tc.nextLine();
    	System.out.println("Ingrese un password");
    	pass=tc.nextInt();
    	tc.nextLine();
    	if(us.equals("admin") && pass==123) {
    		System.out.println("Ha ingresado el sistema");
    		break;
    	}
    	else if(cont>=3) {
    		System.out.println("Ha superado los limites");
    		break;
    	}
    	cont++;
    }
	}

}
