package voltajes;

import java.util.Scanner;

public class voltajes_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub    
    		Scanner sc=new Scanner(System.in);
    		int  x,n;
    		int minimo=0, maximo=0;
    		double promedio=0;
    		int suma=0;
    		
    	System.out.println("Ingrese la cantidad de valores");	
    	n=sc.nextInt();
    	boolean num=true;
    	for(int i=1; i<=n; i++) {
    		System.out.println("Ingrese los numeros");
    		x=sc.nextInt();
    		if(num==true) {
    			maximo=x;
    			minimo=x;
    			num=false;
    		}else {
    		   if(x>maximo) {
    			   maximo=x;
    		   }else {
    			   if(x<minimo) {
    				  minimo=x;
    			   }
    		   }
    	    }
	     }
    	System.out.println("EL MAXIMO DE ESTOS NUMEROS ES:"+maximo);
    	System.out.println("EL MINIMO DE ESTOS NUMEROS ES:"+minimo);
    	System.out.println("EL PROMEDIO DE TODOS ES:"+promedio);
	}
}
	
    	
		




