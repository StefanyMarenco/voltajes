package demo2;

import java.util.Scanner;

public class n_numeros {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner tc= new Scanner(System.in);
		int num, x, suma=0;
		System.out.println("Ingrese la cantidad de un numero");
		num=tc.nextInt();
		for(int i=1; i<=num; i++) {
			System.out.println("Ingrese un numero");
			x=tc.nextInt();
			if(x>0) {
			suma=suma + x;
			System.out.println("La suma de los num"+suma);
		}
			else {
				System.out.println("["+i+"]"+" "+x);
			}
		}
	}

}
