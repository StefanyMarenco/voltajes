package demo2;
import java.util.Scanner;
public class main_practica {

	public static void main(String[] args) {
     //Este programa es para calcular un numero factorial
		
		int número;
		double factorial=1;
		
		Scanner sc= new Scanner(System.in);
		
		do {
			System.out.println("Introduce un numero entero");
			número=sc.nextInt();
			
		} while (número < 0);
		
		//Multiplico los numeros de 1 hasta numero
		
		for(int i=1; i<=número; i++) {
			factorial= factorial *i;
		}
          System.out.println(número+"!="+factorial);		  
	}

}
